﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

namespace Console_0._3
{
    class Program
    {
        static void Main(string[] args)
        {
            bool showMenu = true;
            while (showMenu)
            {
                showMenu = MENU();
            }
        }
        private static bool MENU()
        {
            Console.Clear();
            Console.WriteLine("Pasirinkite:");
            Console.WriteLine("1) Ivesti rankiniu budu");
            Console.WriteLine("2) Sugeneruoti faila");
            Console.WriteLine("3) Iseiti");
            Console.WriteLine("\r\nIveskite pasirinkimo skaiciu: ");

            switch (Console.ReadLine())
            {
                case "1":
                    pirmas();
                    return true;
                case "2":
                    antras();
                    return true;
                case "3":
                    return false;
                default:
                    return true;
            }
        }
        private static void pirmas()
        {
            Console.Write("Iveskite varda: ");
            string name = Console.ReadLine();
            Console.Write("Iveskite pavarde: ");
            string surname = Console.ReadLine();
            Console.Write("Iveskite namu darbu pazymius (naudojant tarpa): ");
            var line = Console.ReadLine();
            var numbers = line.Split(' ');
            var i = 0;
            var total = 0;

            foreach (var number in numbers)
            {
                int num;
                if (Int32.TryParse(number, out num))
                {
                    i++;
                    total = total + num;
                }
            }
            Console.Write("Iveskite Egzamino rezultata: ");
            int egzaminas = Convert.ToInt32(Console.ReadLine());
            double galutinis = 0.3 * (total / i) + (0.7 * egzaminas);
            galutinis = (double)System.Math.Round(galutinis, 2);
            Console.WriteLine("Pavarde          Vardas          Galutinis (Vid.)");
            Console.WriteLine("----------------------------------------------------------------------------");
            Console.WriteLine(surname + "          " + name + "          " + galutinis);
            Console.Write("\r\nPress Enter to return to Main Menu");
            Console.ReadLine();
        }
        private static void antras()
        {
            Console.Clear();
            Console.WriteLine("Is kiek irasu sudaryti faila: ");
            int end = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Iveskite failo pavadinima");
            string filenamex = Console.ReadLine();
            end++;

            string fileName = filenamex + ".txt";

            try
            {  
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                using (FileStream fs = File.Create(fileName))
                {

                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.ToString());
            }

            int i = 1;
            Random x = new Random();
            while (i < end)
            {

                try
                {
                    using (StreamWriter w = File.AppendText(fileName))
                    {
                        w.WriteLine("Vardas" + Convert.ToString(i) + " " + "Pavarde" + Convert.ToString(i) + " " + x.Next(1, 10) + " " + x.Next(1, 10) + " " + x.Next(1, 10) + " " + x.Next(1, 10) + " " + x.Next(1, 10) + " " + x.Next(1, 10) + " " + x.Next(1, 10));
                        i++;
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e);
                }
            }
            Console.WriteLine("Failas sugeneruotas: " + fileName);
            Console.Write("\r\nPress Enter to return to Main Menu");
            Console.ReadLine();
        }
       


    }
}




