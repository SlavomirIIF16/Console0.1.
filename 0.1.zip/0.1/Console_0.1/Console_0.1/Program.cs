﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

namespace Console_0._1
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.Write("Iveskite varda: ");
			string name = Console.ReadLine();
			Console.Write("Iveskite pavarde: ");
			string surname = Console.ReadLine();
			Console.Write("Iveskite namu darbu pazymius (naudojant tarpa): ");
			var line = Console.ReadLine();
			var numbers = line.Split(' ');
			var i = 0;
			var y = 0;
			var total = 0;
			var	total1 = 0;
			var egzaminas2 = 0;
			foreach (var number in numbers)
			{
				int num;
				if (Int32.TryParse(number, out num))
				{
					i++;
					total = total + num;
				}
			}
			Console.Write("Iveskite Egzamino rezultata: ");
			int egzaminas = Convert.ToInt32(Console.ReadLine());
			double galutinis = 0.3 * (total / i) + (0.7 * egzaminas);
			galutinis = (double)System.Math.Round(galutinis, 2);
			Console.WriteLine("Pavarde          Vardas          Galutinis (Vid.)");
			Console.WriteLine("----------------------------------------------------------------------------");
			Console.WriteLine(surname + "          " + name + "          " + galutinis);

			using (TextReader reader = File.OpenText("VGTU.txt"))
			{
				string text = reader.ReadLine();
				string[] bits = text.Split(' ');
				string namefile = bits[0];
				string surnamefile = bits[1];
				
				foreach (var number1 in bits)
				{
					int a;
					if (Int32.TryParse(number1, out a))
					{
						y++;
						total1 = total1 + a;
						egzaminas2 = a;
					}
				}
				total1 = total1 - egzaminas2;
				double galutinis1 = 0.3 * (total1 / y) + (0.7 * egzaminas2);
				galutinis1 = (double)System.Math.Round(galutinis1, 2);
				Console.WriteLine("");
				Console.WriteLine("NUSKAITYMAS IS FAILO");
				Console.WriteLine("");
				Console.WriteLine("Pavarde          Vardas          Galutinis (Vid.)");
				Console.WriteLine("----------------------------------------------------------------------------");
				Console.WriteLine(surnamefile + "          " + namefile + "          " + galutinis1);
							}

		}
	}
}
